"use client";

export function ConnectWalletBtn() {
  return <w3m-button />;
}
