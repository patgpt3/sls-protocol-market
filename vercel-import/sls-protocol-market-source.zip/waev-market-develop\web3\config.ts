// export const marketAddress = "0xeB5db2cb2F264682f9bA841A1aEa61C370332ACd"; // to delete
// export const marketAddress = "0xc3DcE7fEB218520Bc289E3E51D6fd6AEf4C917DA"; // to delete
// export const marketAddress = "0xa80e985729fca866E61fe52CCD9b99687307913A";
// export const marketAddress = "0x81d75Dec1191585Cc04805B799f8549fb01FfA0A";
export const marketAddress = "0x381CFAfe120c0c2fFB35Fdbb06791c4BfD61eEAb";
export const chainId = 100;
// export const defaultRPC = "https://bitter-chaotic-shard.xdai.quiknode.pro/464b20e08fa724cf922fc2197e9015bfb464c88a";
export const defaultRPC = "https://rpc.gnosischain.com/";

