export type GrantType = {
  grantorDeploymentId: any;
  dataId: any;
  expires: number;
  requiredFlags: any;
  readRoles: any;
};
