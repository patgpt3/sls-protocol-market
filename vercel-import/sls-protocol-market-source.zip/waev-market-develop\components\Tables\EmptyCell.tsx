import MDBox from "../Elements/MDBox";
import MDTypography from "../Elements/MDTypography";

export const EmptyCell = () => (
  <MDBox>
    <MDTypography>-</MDTypography>
  </MDBox>
);
